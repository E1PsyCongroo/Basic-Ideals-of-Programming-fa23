// somehow conver .h and .c into a library
int helper_func();
