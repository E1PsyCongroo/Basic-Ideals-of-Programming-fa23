#include "lab6_helper.h"

int helper_func() {

    int x = 45;
    int y = x;
    int d;
    x = 213;
    for (y = 0; y < x*100; y ++) {
        int z = 24;
        int a;
        int b;
        int c;

        a = z * 2;
        b = a -5*x;
        c = a * 45 / 529 * 100900090;
        d = a + b -c;
    }
    d = x;
    return d * 1;
}
